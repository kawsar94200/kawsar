import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNavbar from "@/components/layout/MobileNavbar";
import Home from "@/pages/Home";
import ProductListing from "@/pages/ProductListing";
import ProductDetail from "@/pages/ProductDetail";
import Cart from "@/pages/Cart";
import Checkout from "@/pages/Checkout";
import SearchResults from "@/pages/SearchResults";
import { useEffect, useState } from "react";
import { getSessionId } from "./lib/utils";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/category/:slug" component={ProductListing} />
      <Route path="/product/:slug" component={ProductDetail} />
      <Route path="/cart" component={Cart} />
      <Route path="/checkout" component={Checkout} />
      <Route path="/search" component={SearchResults} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [sessionId, setSessionId] = useState<string | null>(null);
  
  useEffect(() => {
    // Initialize session ID
    const id = getSessionId();
    setSessionId(id);
  }, []);

  // Only render the app when the session ID is set
  if (!sessionId) {
    return null;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Header />
        <main className="container mx-auto px-4 py-4">
          <Router />
        </main>
        <Footer />
        <MobileNavbar />
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
