import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { getSessionId } from "@/lib/utils";

export default function Header() {
  const [searchQuery, setSearchQuery] = useState("");
  const [, navigate] = useLocation();
  
  // Get cart items count
  const { data: cartItems = [] } = useQuery({
    queryKey: [`/api/cart`],
    meta: {
      headers: {
        "x-session-id": getSessionId(),
      },
    },
  });
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      {/* Top Header */}
      <div className="bg-primary text-white py-1 text-xs">
        <div className="container mx-auto px-4 flex justify-between">
          <div className="flex space-x-4">
            <a href="#" className="hover:underline">Save More on App</a>
            <a href="#" className="hover:underline">Sell on KAWSAR</a>
            <a href="#" className="hover:underline">Customer Care</a>
            <a href="#" className="hover:underline">Track My Order</a>
          </div>
          <div>
            <a href="#" className="hover:underline">Signup / Login</a>
          </div>
        </div>
      </div>
      
      {/* Main Header */}
      <div className="container mx-auto px-4 py-2 flex items-center">
        {/* Mobile Menu Button */}
        <button className="mr-2 p-1 lg:hidden text-secondary">
          <i className="fa-solid fa-bars text-xl"></i>
        </button>
        
        {/* Logo */}
        <Link href="/" className="text-secondary text-3xl font-bold mr-2 lg:mr-8">
          KAWSAR
        </Link>
        
        {/* Search Bar */}
        <div className="flex-grow mx-2">
          <form onSubmit={handleSearch} className="relative">
            <Input
              type="text"
              placeholder="Search in KAWSAR"
              className="w-full py-2 px-4 border border-secondary rounded-sm focus:outline-none"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit"
              className="absolute right-0 top-0 h-full bg-secondary text-white px-4 rounded-r-sm"
            >
              <i className="fa-solid fa-magnifying-glass"></i>
            </Button>
          </form>
        </div>
        
        {/* Icons */}
        <div className="flex space-x-4 items-center ml-4">
          <a href="#" className="text-dark-gray hidden md:block">
            <i className="fa-solid fa-user text-xl"></i>
          </a>
          <Link href="/cart" className="text-dark-gray relative">
            <i className="fa-solid fa-cart-shopping text-xl"></i>
            {cartItems.length > 0 && (
              <Badge 
                className="absolute -top-2 -right-2 bg-secondary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center p-0"
              >
                {cartItems.length}
              </Badge>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
