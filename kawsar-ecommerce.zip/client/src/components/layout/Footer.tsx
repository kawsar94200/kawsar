import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-white mt-8 pt-8 pb-4">
      <div className="container mx-auto px-4">
        {/* Top Footer */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 pb-6 border-b">
          <div>
            <h3 className="font-bold text-lg mb-4">Customer Care</h3>
            <ul className="space-y-2 text-sm text-dark-gray">
              <li><a href="#" className="hover:text-secondary">Help Center</a></li>
              <li><a href="#" className="hover:text-secondary">How to Buy</a></li>
              <li><a href="#" className="hover:text-secondary">Returns & Refunds</a></li>
              <li><a href="#" className="hover:text-secondary">Contact Us</a></li>
              <li><a href="#" className="hover:text-secondary">Terms & Conditions</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-4">KAWSAR</h3>
            <ul className="space-y-2 text-sm text-dark-gray">
              <li><a href="#" className="hover:text-secondary">About KAWSAR</a></li>
              <li><a href="#" className="hover:text-secondary">Digital Payments</a></li>
              <li><a href="#" className="hover:text-secondary">KAWSAR Blog</a></li>
              <li><a href="#" className="hover:text-secondary">KAWSAR Cares</a></li>
              <li><a href="#" className="hover:text-secondary">Privacy Policy</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-4">Make Money With Us</h3>
            <ul className="space-y-2 text-sm text-dark-gray">
              <li><a href="#" className="hover:text-secondary">Sell on KAWSAR</a></li>
              <li><a href="#" className="hover:text-secondary">Join KAWSAR Affiliate Program</a></li>
              <li><a href="#" className="hover:text-secondary">Become a KAWSAR Seller</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-lg mb-4">KAWSAR International</h3>
            <div className="grid grid-cols-3 gap-2 text-center text-sm">
              <a href="#" className="border p-2 hover:text-secondary">Pakistan</a>
              <a href="#" className="border p-2 hover:text-secondary">Nepal</a>
              <a href="#" className="border p-2 hover:text-secondary">Sri Lanka</a>
              <a href="#" className="border p-2 hover:text-secondary">Myanmar</a>
              <a href="#" className="border p-2 hover:text-secondary">Bangladesh</a>
            </div>
            <h3 className="font-bold text-lg mb-2 mt-4">Payment Methods</h3>
            <div className="flex gap-2 flex-wrap">
              <img src="https://icms-image.slatic.net/images/ims-web/9a08515e-f7e8-461e-a6b3-ae003997dbf5.png" alt="Cash on Delivery" className="h-6" />
              <img src="https://icms-image.slatic.net/images/ims-web/6cb39cbf-6430-4b34-8da2-d415586717f3.png" alt="bKash" className="h-6" />
              <img src="https://icms-image.slatic.net/images/ims-web/e0672529-f99e-462f-9ba6-8a33f33efa8a.png" alt="Visa" className="h-6" />
              <img src="https://icms-image.slatic.net/images/ims-web/da9c572c-4dbf-4ecd-8e80-c5d7a0012950.png" alt="Mastercard" className="h-6" />
            </div>
          </div>
        </div>
        
        {/* Bottom Footer */}
        <div className="pt-6 text-center text-sm text-dark-gray">
          <p>&copy; KAWSAR {new Date().getFullYear()}. All Rights Reserved</p>
        </div>
      </div>
    </footer>
  );
}
