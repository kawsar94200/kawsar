import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery } from "@tanstack/react-query";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import CategorySidebar from "@/components/layout/CategorySidebar";
import ProductCard from "@/components/product/ProductCard";
import { Product } from "@shared/schema";

export default function SearchResults() {
  const [, params] = useLocation();
  const searchParams = new URLSearchParams(params);
  const query = searchParams.get("q") || "";
  const [sortBy, setSortBy] = useState("default");
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: [`/api/search?q=${encodeURIComponent(query)}`],
    enabled: !!query,
  });
  
  // Sort products based on selected option
  useEffect(() => {
    if (!products) return;
    
    let sorted = [...products];
    
    switch (sortBy) {
      case "price-asc":
        sorted.sort((a, b) => Number(a.price) - Number(b.price));
        break;
      case "price-desc":
        sorted.sort((a, b) => Number(b.price) - Number(a.price));
        break;
      case "newest":
        // In this mock, we don't have a date field, so keep default order
        break;
      case "popularity":
        sorted.sort((a, b) => b.reviewCount - a.reviewCount);
        break;
      case "rating":
        sorted.sort((a, b) => Number(b.rating) - Number(a.rating));
        break;
      default:
        // Default sorting, keep as is
        break;
    }
    
    setFilteredProducts(sorted);
  }, [products, sortBy]);
  
  return (
    <>
      <Helmet>
        <title>{`Search Results for "${query}" - KAWSAR`}</title>
        <meta name="description" content={`View search results for "${query}" from KAWSAR online shopping mall. Find the best deals on electronics, fashion, home appliances and more.`} />
      </Helmet>
      
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        <CategorySidebar />
        
        <div className="lg:col-span-4">
          {/* Search Results Header */}
          <div className="bg-white rounded shadow p-4 mb-4 flex justify-between items-center">
            <h1 className="text-xl font-bold">
              {isLoading ? (
                <Skeleton className="h-8 w-40" />
              ) : (
                `Search Results for "${query}"`
              )}
            </h1>
            
            <div className="flex items-center">
              <span className="text-sm mr-2 text-dark-gray">Sort by:</span>
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Default" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="default">Default</SelectItem>
                  <SelectItem value="price-asc">Price: Low to High</SelectItem>
                  <SelectItem value="price-desc">Price: High to Low</SelectItem>
                  <SelectItem value="popularity">Popularity</SelectItem>
                  <SelectItem value="rating">Rating</SelectItem>
                  <SelectItem value="newest">Newest First</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {/* Products Grid */}
          <div className="bg-white rounded shadow p-4">
            {isLoading ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {Array(8).fill(0).map((_, index) => (
                  <div key={index} className="border rounded">
                    <Skeleton className="w-full h-40" />
                    <div className="p-2">
                      <Skeleton className="w-full h-4 mt-2" />
                      <Skeleton className="w-2/3 h-4 mt-2" />
                      <Skeleton className="w-1/2 h-4 mt-2" />
                    </div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="py-12 text-center">
                <i className="fa-solid fa-search text-4xl text-gray-300 mb-4"></i>
                <h2 className="text-xl mb-2">No results found</h2>
                <p className="text-dark-gray">
                  We couldn't find any products matching "{query}". 
                  Try checking your spelling or using more general terms.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
