import { db } from './db';
import { MemStorage } from './storage';
import * as schema from '@shared/schema';

/**
 * This script seeds the database with initial sample data
 */
async function seedDatabase() {
  console.log("🌱 Seeding database with initial data...");

  try {
    // Create a temporary memory storage to get the sample data
    const memStorage = new MemStorage();
    
    // Seed categories
    const categories = await memStorage.getCategories();
    console.log(`Adding ${categories.length} categories...`);
    for (const category of categories) {
      const { id, ...categoryData } = category;
      await db.insert(schema.categories).values(categoryData).onConflictDoNothing();
    }
    
    // Seed products
    const products = await memStorage.getProducts();
    console.log(`Adding ${products.length} products...`);
    for (const product of products) {
      const { id, ...productData } = product;
      // Convert numeric fields to strings for PostgreSQL
      await db.insert(schema.products).values({
        ...productData,
        price: productData.price.toString(),
        originalPrice: productData.originalPrice?.toString() || null,
        rating: productData.rating?.toString() || null,
      }).onConflictDoNothing();
    }
    
    // Seed banners
    const banners = await memStorage.getBanners();
    console.log(`Adding ${banners.length} banners...`);
    for (const banner of banners) {
      const { id, ...bannerData } = banner;
      await db.insert(schema.banners).values(bannerData).onConflictDoNothing();
    }
    
    console.log("✅ Database seeded successfully!");
  } catch (error) {
    console.error("Error seeding database:", error);
    throw error;
  }
}

// Execute right away
seedDatabase()
  .then(() => {
    console.log("Database seeding completed successfully");
    // Don't exit the process when imported
    if (process.argv[1]?.endsWith('db-seed.ts')) {
      process.exit(0);
    }
  })
  .catch((error) => {
    console.error("Seeding failed:", error);
    if (process.argv[1]?.endsWith('db-seed.ts')) {
      process.exit(1);
    }
  });

export { seedDatabase };