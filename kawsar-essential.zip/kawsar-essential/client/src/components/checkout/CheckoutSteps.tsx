import { cn } from "@/lib/utils";

interface CheckoutStepsProps {
  currentStep: number;
}

export default function CheckoutSteps({ currentStep }: CheckoutStepsProps) {
  const steps = [
    { id: 1, name: "Cart", icon: "fa-cart-shopping" },
    { id: 2, name: "Address", icon: "fa-map-marker-alt" },
    { id: 3, name: "Payment", icon: "fa-credit-card" },
    { id: 4, name: "Confirmation", icon: "fa-check-circle" }
  ];

  return (
    <div className="mb-6">
      <div className="flex items-center justify-between">
        {steps.map((step, index) => (
          <div key={step.id} className="flex flex-col items-center relative w-full">
            {/* Connector */}
            {index > 0 && (
              <div 
                className={cn(
                  "absolute top-4 w-full right-1/2 h-1 -z-10", 
                  step.id <= currentStep ? "bg-secondary" : "bg-gray-200"
                )}
              ></div>
            )}
            
            {/* Circle */}
            <div 
              className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center",
                step.id < currentStep ? "bg-secondary text-white" : 
                step.id === currentStep ? "border-2 border-secondary text-secondary" : 
                "bg-gray-200 text-gray-500"
              )}
            >
              <i className={`fa-solid ${step.icon}`}></i>
            </div>
            
            {/* Label */}
            <span 
              className={cn(
                "text-sm mt-2", 
                step.id <= currentStep ? "text-secondary font-medium" : "text-gray-500"
              )}
            >
              {step.name}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
