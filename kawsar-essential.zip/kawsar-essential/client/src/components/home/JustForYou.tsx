import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import ProductCard from "@/components/product/ProductCard";
import { Product } from "@shared/schema";

export default function JustForYou() {
  const [page, setPage] = useState(1);
  const [allProducts, setAllProducts] = useState<Product[]>([]);
  const limit = 8;
  
  const { data: products = [], isLoading, isFetching } = useQuery<Product[]>({
    queryKey: [`/api/products?limit=${limit}&offset=${(page - 1) * limit}`],
  });

  useEffect(() => {
    if (products.length > 0) {
      setAllProducts(prevProducts => {
        // Filter out duplicates by id
        const productIds = new Set(prevProducts.map(p => p.id));
        const newProducts = products.filter(p => !productIds.has(p.id));
        return [...prevProducts, ...newProducts];
      });
    }
  }, [products]);

  const handleLoadMore = () => {
    setPage(prevPage => prevPage + 1);
  };

  if (isLoading && page === 1) {
    return (
      <div className="bg-white rounded shadow p-4">
        <h2 className="font-bold text-xl mb-4">JUST FOR YOU</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {Array(8).fill(0).map((_, index) => (
            <div key={index} className="border rounded">
              <Skeleton className="w-full h-40" />
              <div className="p-2">
                <Skeleton className="w-full h-4 mt-2" />
                <Skeleton className="w-2/3 h-4 mt-2" />
                <Skeleton className="w-1/2 h-4 mt-2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded shadow p-4">
      <h2 className="font-bold text-xl mb-4">JUST FOR YOU</h2>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {allProducts.map(product => (
          <ProductCard key={product.id} product={product} />
        ))}
        
        {/* Show skeleton loaders when loading more */}
        {isFetching && page > 1 && Array(4).fill(0).map((_, index) => (
          <div key={`skeleton-${index}`} className="border rounded">
            <Skeleton className="w-full h-40" />
            <div className="p-2">
              <Skeleton className="w-full h-4 mt-2" />
              <Skeleton className="w-2/3 h-4 mt-2" />
              <Skeleton className="w-1/2 h-4 mt-2" />
            </div>
          </div>
        ))}
        
        {/* Load More Button */}
        <div className="col-span-full mt-4 flex justify-center">
          <Button 
            variant="outline" 
            className="border border-secondary text-secondary py-2 px-6 rounded-sm hover:bg-secondary hover:text-white transition-colors"
            onClick={handleLoadMore}
            disabled={isFetching}
          >
            {isFetching ? "Loading..." : "Load More"}
          </Button>
        </div>
      </div>
    </div>
  );
}
