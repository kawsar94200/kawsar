import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import ProductCard from "@/components/product/ProductCard";
import { Product } from "@shared/schema";

export default function FlashSale() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 1,
    minutes: 30,
    seconds: 0
  });
  
  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products?flashDeal=true"]
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds -= 1;
        } else if (minutes > 0) {
          minutes -= 1;
          seconds = 59;
        } else if (hours > 0) {
          hours -= 1;
          minutes = 59;
          seconds = 59;
        }
        
        if (hours === 0 && minutes === 0 && seconds === 0) {
          clearInterval(timer);
        }
        
        return { hours, minutes, seconds };
      });
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="bg-white rounded shadow mb-4">
        <div className="flash-sale-countdown text-white p-4 flex items-center justify-between">
          <div>
            <h2 className="font-bold text-xl">FLASH SALE</h2>
            <p className="text-sm">Hurry up! Offers ending soon</p>
          </div>
          <div className="flex space-x-2">
            <Skeleton className="w-12 h-12 bg-white/20" />
            <Skeleton className="w-12 h-12 bg-white/20" />
            <Skeleton className="w-12 h-12 bg-white/20" />
          </div>
          <Skeleton className="w-32 h-8 bg-white/20 hidden md:block" />
        </div>
        
        <div className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {Array(4).fill(0).map((_, index) => (
              <div key={index} className="border rounded">
                <Skeleton className="w-full h-40" />
                <div className="p-2">
                  <Skeleton className="w-full h-4 mt-2" />
                  <Skeleton className="w-2/3 h-4 mt-2" />
                  <Skeleton className="w-1/2 h-4 mt-2" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // Format time with leading zeros
  const formatTime = (num: number) => num.toString().padStart(2, '0');

  return (
    <div className="bg-white rounded shadow mb-4">
      <div className="flash-sale-countdown text-white p-4 flex items-center justify-between">
        <div>
          <h2 className="font-bold text-xl">FLASH SALE</h2>
          <p className="text-sm">Hurry up! Offers ending soon</p>
        </div>
        <div className="flex space-x-2">
          <div className="bg-white text-secondary rounded px-2 py-1 text-center">
            <span className="block text-xl font-bold">{formatTime(timeLeft.hours)}</span>
            <span className="text-xs">Hrs</span>
          </div>
          <div className="bg-white text-secondary rounded px-2 py-1 text-center">
            <span className="block text-xl font-bold">{formatTime(timeLeft.minutes)}</span>
            <span className="text-xs">Min</span>
          </div>
          <div className="bg-white text-secondary rounded px-2 py-1 text-center">
            <span className="block text-xl font-bold">{formatTime(timeLeft.seconds)}</span>
            <span className="text-xs">Sec</span>
          </div>
        </div>
        <Link href="/flash-sale" className="text-sm underline hidden md:block">SHOP ALL PRODUCTS</Link>
      </div>
      
      {/* Flash Sale Product Grid */}
      <div className="p-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {products.map(product => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
