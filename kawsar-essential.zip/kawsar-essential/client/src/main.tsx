import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";
import { Helmet, HelmetProvider } from "react-helmet-async";

createRoot(document.getElementById("root")!).render(
  <HelmetProvider>
    <Helmet>
      <title>KAWSAR - Online Shopping Mall</title>
      <meta name="description" content="KAWSAR - The biggest online shopping mall in Bangladesh. Shop online for electronics, clothing, home appliances, and more with great deals and discounts." />
      <meta property="og:title" content="KAWSAR - Online Shopping Mall" />
      <meta property="og:description" content="KAWSAR - The biggest online shopping mall in Bangladesh. Shop online for electronics, clothing, home appliances, and more with great deals and discounts." />
      <meta property="og:type" content="website" />
      <meta property="og:url" content="https://www.kawsar.com.bd/" />
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossOrigin="anonymous" referrerPolicy="no-referrer" />
      <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet" />
    </Helmet>
    <App />
  </HelmetProvider>
);
