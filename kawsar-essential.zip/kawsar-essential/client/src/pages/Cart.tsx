import { useState, useMemo } from "react";
import { Link, useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatCurrency, getSessionId } from "@/lib/utils";
import CartItem from "@/components/cart/CartItem";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

interface ExtendedCartItem {
  id: number;
  productId: number;
  sessionId: string;
  quantity: number;
  product: Product;
}

export default function Cart() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const { data: cartItems = [], isLoading } = useQuery<ExtendedCartItem[]>({
    queryKey: ["/api/cart"],
    headers: {
      "x-session-id": getSessionId(),
    },
  });
  
  const { mutate: clearCart, isPending: isClearing } = useMutation({
    mutationFn: async () => {
      return await apiRequest("DELETE", "/api/cart");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Cart cleared",
        description: "All items have been removed from your cart",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to clear cart",
        variant: "destructive",
      });
    }
  });
  
  // Calculate cart summary
  const cartSummary = useMemo(() => {
    const subtotal = cartItems.reduce((sum, item) => {
      return sum + (Number(item.product.price) * item.quantity);
    }, 0);
    
    const shipping = subtotal > 0 ? 50 : 0; // 50 BDT shipping fee
    const total = subtotal + shipping;
    
    return { subtotal, shipping, total };
  }, [cartItems]);
  
  if (isLoading) {
    return (
      <div className="bg-white rounded shadow p-6">
        <h1 className="text-2xl font-bold mb-6">Shopping Cart</h1>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {Array(3).fill(0).map((_, index) => (
              <div key={index} className="border-b py-4">
                <div className="flex">
                  <Skeleton className="w-32 h-32" />
                  <div className="ml-4 space-y-2 flex-grow">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-8 w-32" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="lg:col-span-1">
            <div className="border rounded p-4">
              <Skeleton className="h-6 w-1/2 mb-4" />
              <div className="space-y-4">
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <div className="flex justify-between">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Separator />
                <div className="flex justify-between">
                  <Skeleton className="h-6 w-24" />
                  <Skeleton className="h-6 w-20" />
                </div>
                <Skeleton className="h-10 w-full" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <>
      <Helmet>
        <title>Shopping Cart - KAWSAR</title>
        <meta name="description" content="View your shopping cart and checkout your selected items from KAWSAR online shopping mall." />
      </Helmet>
      
      <div className="bg-white rounded shadow p-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Shopping Cart</h1>
          {cartItems.length > 0 && (
            <Button 
              variant="ghost" 
              className="text-red-500 hover:text-red-700 hover:bg-red-50"
              onClick={() => clearCart()}
              disabled={isClearing}
            >
              <i className="fa-solid fa-trash-alt mr-2"></i>
              Clear Cart
            </Button>
          )}
        </div>
        
        {cartItems.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              {cartItems.map(item => (
                <CartItem 
                  key={item.id} 
                  id={item.id} 
                  product={item.product} 
                  quantity={item.quantity}
                />
              ))}
            </div>
            
            <div className="lg:col-span-1">
              <div className="border rounded p-4 sticky top-24">
                <h2 className="font-bold text-lg mb-4">Order Summary</h2>
                <div className="space-y-4">
                  <div className="flex justify-between text-dark-gray">
                    <span>Subtotal ({cartItems.length} items)</span>
                    <span>{formatCurrency(cartSummary.subtotal)}</span>
                  </div>
                  <div className="flex justify-between text-dark-gray">
                    <span>Shipping Fee</span>
                    <span>{formatCurrency(cartSummary.shipping)}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold text-lg">
                    <span>Total</span>
                    <span className="text-secondary">{formatCurrency(cartSummary.total)}</span>
                  </div>
                  <Button 
                    className="w-full bg-secondary hover:bg-secondary/90 mt-4"
                    onClick={() => navigate("/checkout")}
                  >
                    Proceed to Checkout
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <i className="fa-solid fa-cart-arrow-down text-gray-300 text-5xl mb-4"></i>
            <h2 className="text-xl mb-2">Your cart is empty</h2>
            <p className="text-dark-gray mb-6">Looks like you haven't added anything to your cart yet.</p>
            <Button onClick={() => navigate("/")}>Continue Shopping</Button>
          </div>
        )}
      </div>
    </>
  );
}
