import { useState } from "react";
import { useParams, useLocation } from "wouter";
import { Helmet } from "react-helmet-async";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { formatCurrency, getSessionId } from "@/lib/utils";
import StarRating from "@/components/product/StarRating";
import { Product } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function ProductDetail() {
  const { slug } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  
  const { data: product, isLoading } = useQuery<Product>({
    queryKey: [`/api/products/${slug}`],
    enabled: !!slug,
  });
  
  const { mutate: addToCart, isPending } = useMutation({
    mutationFn: async () => {
      if (!product) throw new Error("Product not found");
      return await apiRequest("POST", "/api/cart", {
        productId: product.id,
        quantity
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Added to cart",
        description: "Product added to your cart successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to add product to cart",
        variant: "destructive",
      });
    }
  });
  
  const { mutate: buyNow, isPending: isBuyingNow } = useMutation({
    mutationFn: async () => {
      if (!product) throw new Error("Product not found");
      return await apiRequest("POST", "/api/cart", {
        productId: product.id,
        quantity
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      navigate("/cart");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to buy product",
        variant: "destructive",
      });
    }
  });
  
  const handleQuantityChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (value > 0 && product && value <= product.stock) {
      setQuantity(value);
    }
  };
  
  const handleIncrement = () => {
    if (product && quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };
  
  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  if (isLoading) {
    return (
      <div className="bg-white rounded shadow p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <Skeleton className="w-full h-80" />
          
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-6 w-1/3" />
            <Skeleton className="h-4 w-1/4" />
            <Separator />
            <Skeleton className="h-20 w-full" />
            <div className="flex space-x-4">
              <Skeleton className="h-10 w-1/2" />
              <Skeleton className="h-10 w-1/2" />
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  if (!product) {
    return (
      <div className="bg-white rounded shadow p-6 text-center py-12">
        <i className="fa-solid fa-circle-exclamation text-red-500 text-4xl mb-4"></i>
        <h1 className="text-2xl font-bold mb-2">Product Not Found</h1>
        <p className="text-dark-gray mb-6">The product you're looking for does not exist or has been removed.</p>
        <Button onClick={() => navigate("/")}>Back to Home</Button>
      </div>
    );
  }
  
  const discountPercentage = product.discountPercentage || 0;
  
  return (
    <>
      <Helmet>
        <title>{`${product.name} - KAWSAR`}</title>
        <meta name="description" content={product.description} />
        <meta property="og:title" content={`${product.name} - KAWSAR`} />
        <meta property="og:description" content={product.description} />
        <meta property="og:image" content={product.image} />
      </Helmet>
      
      <div className="bg-white rounded shadow p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Product Image */}
          <div className="flex justify-center items-center border p-4">
            <img 
              src={product.image} 
              alt={product.name} 
              className="max-w-full max-h-80 object-contain"
            />
          </div>
          
          {/* Product Details */}
          <div className="space-y-4">
            <h1 className="text-2xl font-bold">{product.name}</h1>
            
            <div className="flex items-center">
              <StarRating rating={Number(product.rating)} />
              <span className="text-light-gray ml-2">{product.reviewCount} Reviews</span>
            </div>
            
            <div className="flex items-end gap-2">
              <span className="text-secondary text-3xl font-bold">
                {formatCurrency(Number(product.price))}
              </span>
              
              {product.originalPrice && Number(product.originalPrice) > Number(product.price) && (
                <span className="text-light-gray line-through text-lg">
                  {formatCurrency(Number(product.originalPrice))}
                </span>
              )}
              
              {discountPercentage > 0 && (
                <span className="bg-red-100 text-red-600 text-sm px-2 py-1 rounded">
                  -{discountPercentage}% OFF
                </span>
              )}
            </div>
            
            <Separator />
            
            <div>
              <p className="text-dark-gray text-sm mb-4">{product.description}</p>
              
              <div className="flex items-center space-x-4 mb-6">
                <span className="text-dark-gray">Quantity:</span>
                <div className="flex items-center border rounded">
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleDecrement}
                    disabled={quantity <= 1}
                    className="px-3 py-0 h-10"
                  >
                    <i className="fa-solid fa-minus"></i>
                  </Button>
                  <input
                    type="number"
                    min="1"
                    max={product.stock}
                    value={quantity}
                    onChange={handleQuantityChange}
                    className="w-16 text-center border-0 focus:outline-none focus:ring-0"
                  />
                  <Button 
                    type="button" 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleIncrement}
                    disabled={quantity >= product.stock}
                    className="px-3 py-0 h-10"
                  >
                    <i className="fa-solid fa-plus"></i>
                  </Button>
                </div>
                <span className="text-dark-gray text-sm">
                  {product.stock} available
                </span>
              </div>
              
              <div className="flex space-x-4">
                <Button 
                  onClick={() => addToCart()}
                  disabled={isPending || product.stock === 0}
                  variant="outline"
                  className="w-1/2 border-secondary text-secondary hover:bg-secondary hover:text-white"
                >
                  <i className="fa-solid fa-cart-plus mr-2"></i>
                  {isPending ? "Adding..." : "Add to Cart"}
                </Button>
                <Button 
                  onClick={() => buyNow()}
                  disabled={isBuyingNow || product.stock === 0}
                  className="w-1/2 bg-secondary hover:bg-secondary/90"
                >
                  {isBuyingNow ? "Processing..." : "Buy Now"}
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        {/* Product Tabs */}
        <div className="mt-8">
          <Tabs defaultValue="details">
            <TabsList className="w-full grid grid-cols-3">
              <TabsTrigger value="details">Details</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="details" className="p-4">
              <p className="text-dark-gray">{product.description}</p>
            </TabsContent>
            <TabsContent value="specifications" className="p-4">
              <div className="space-y-2">
                <div className="grid grid-cols-3 border-b pb-2">
                  <span className="font-medium">Category</span>
                  <span className="col-span-2">Category {product.categoryId}</span>
                </div>
                <div className="grid grid-cols-3 border-b pb-2">
                  <span className="font-medium">Stock</span>
                  <span className="col-span-2">{product.stock} units</span>
                </div>
                <div className="grid grid-cols-3 border-b pb-2">
                  <span className="font-medium">Rating</span>
                  <span className="col-span-2">{product.rating} out of 5</span>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="p-4">
              <div className="text-center py-4">
                <p className="text-dark-gray">
                  This product has {product.reviewCount} reviews with an average rating of {product.rating} out of 5.
                </p>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </>
  );
}
